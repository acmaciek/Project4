Tim Peloza - Exam Grader (FrameGrader)
Maciek - Exam Taker
Alexander - Exam Builder

How to run:

1.Type 'make' into console inside of the src folder
2.Double click the jar file of the program you want to run.